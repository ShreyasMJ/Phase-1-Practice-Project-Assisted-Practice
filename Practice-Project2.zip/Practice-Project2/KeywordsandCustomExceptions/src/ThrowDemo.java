
public class ThrowDemo {

}
